package com.example.carapp
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.Charset
import java.util.*


class MainActivity : AppCompatActivity() {
    val delimiter: Byte = 33
    var readBufferPosition = 0
    var mmSocket: BluetoothSocket? = null
    var mmDevice: BluetoothDevice? = null


    @Throws(IOException::class)
    fun writebt(socket: BluetoothSocket?, message: String) {
        mmSocket = socket
        var mmOutputStream: OutputStream? = null
        mmOutputStream = mmSocket!!.outputStream
        mmOutputStream.write(message.toByteArray())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val handler = Handler()
        val mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        val REQUEST_ENABLE_BT = 9999
        if (!mBluetoothAdapter.isEnabled) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT)
        }


        class workerThread(private val btMsg: String) : Runnable {
            override fun run() {
                while (true) {
                    var bytesAvailable: Int
                    try {
                        val mmInputStream: InputStream
                        mmInputStream = mmSocket!!.inputStream
                        bytesAvailable = mmInputStream.available()
                        if (bytesAvailable > 0) {
                            val packetBytes = ByteArray(bytesAvailable)
                            Log.e("recv bt", "bytes available")
                            val readBuffer = ByteArray(1024)
                            mmInputStream.read(packetBytes)
                            for (i in 0 until bytesAvailable) {
                                val b = packetBytes[i]
                                if (b == delimiter) {
                                    val encodedBytes = ByteArray(readBufferPosition)
                                    System.arraycopy(
                                        readBuffer,
                                        0,
                                        encodedBytes,
                                        0,
                                        encodedBytes.size
                                    )
                                    val data = String(encodedBytes, Charset.forName("UTF-8"))
                                    readBufferPosition = 0
                                    handler.post { }
                                    break
                                } else {
                                    readBuffer[readBufferPosition++] = b
                                }
                            }
                        }
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                }
            }
        }

        val uparrow = findViewById<View>(R.id.uparrow) as ImageButton
        val status = findViewById<View>(R.id.status) as TextView
        uparrow.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                status.text = "F"
                try {
                    writebt(mmSocket, "F")
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            } else if (event.action == MotionEvent.ACTION_UP) {
                status.text = "None"
                try {
                    writebt(mmSocket, "s")
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
            true
        }
        val rightarrow = findViewById<View>(R.id.rightarrow) as ImageButton
        rightarrow.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                status.text = "R"
                try {
                    writebt(mmSocket, "R")
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            } else if (event.action == MotionEvent.ACTION_UP) {
                status.text = "None"
                try {
                    writebt(mmSocket, "s")
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
            true
        }
        val downarrow = findViewById<View>(R.id.downarrow) as ImageButton
        downarrow.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                status.text = "B"
                try {
                    writebt(mmSocket, "B")
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            } else if (event.action == MotionEvent.ACTION_UP) {
                status.text = "None"
                try {
                    writebt(mmSocket, "s")
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
            true
        }
        val leftarrow = findViewById<View>(R.id.leftarrow) as ImageButton
        leftarrow.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                status.text = "L"
                try {
                    writebt(mmSocket, "L")
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            } else if (event.action == MotionEvent.ACTION_UP) {
                status.text = "None"
                try {
                    writebt(mmSocket, "s")
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
            true
        }
        val connect = findViewById<View>(R.id.button) as Button
        val textview = findViewById<View>(R.id.textView) as TextView
        connect.setOnClickListener {
            try {

                if (!mmSocket?.isConnected()!!) {
                    connect.text = "Connecting... Please Wait..."
                    mmSocket!!.connect()
                    connect.text = "Connected"
                    Thread(workerThread("hello")).start()
                    uparrow.visibility = View.VISIBLE
                    downarrow.visibility = View.VISIBLE
                    leftarrow.visibility = View.VISIBLE
                    rightarrow.visibility = View.VISIBLE
                    textview.visibility = View.INVISIBLE
                    connect.visibility = View.INVISIBLE
                }
            } catch (e: IOException) {
                e.printStackTrace()
                connect.text = "Failed to Connect"
            }
        }
        val pairedDevices = mBluetoothAdapter.bondedDevices
        if (pairedDevices.size > 0) {
            for (device in pairedDevices) {
                if (device.name == "myraspberry")
                {
                    mmDevice = device
                    break
                }
            }
        }
    }
}

